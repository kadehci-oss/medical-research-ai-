# Medical Research AI — DNS çözümü ve bağımsız klinik validasyon devri

NCBI DNS engeli yerel bu çalışma konteynerine aittir. Bu paket gerçek `esearch` ve `efetch` çağrılarını test eder; mock kullanmaz, başarısızlık halinde hata koduyla çıkar. `ncbi_live_results.json` kayıt dosyası üretir.

## Çalıştırma
1. Bu dosyaları GitHub deposunun köküne aynı dizin yapısıyla ekleyin.
2. GitHub **Actions > Live NCBI validation (on demand) > Run workflow** başlatın. Bu kontrol GitHub runner üzerinde çalışır, bu konteynerdeki DNS ayarlarından bağımsızdır.
3. Çıktı için `ncbi-live-validation` artifact'ini açın. PASS gerçek ESearch/EFetch kimlik testlerinin çalıştığını gösterir; tüm uygulama uçtan uca klinik doğrulaması değildir.
4. UZMAN_HEKIM_DEGERLENDIRME.md protokolünü klinik bağımsız değerlendiricilere ve gerçek sabit test çıktılarına uygulayın. Boş form = onay değil.

**Dürüst sınır:** Kodun GitHub'a yüklenmesi ve GitHub Actions'ın çalıştırılması bu çalışma ortamının mevcut GitHub yazma izniyle yapılamadı. Ayrıca canlı API doğrulaması ve uzman imzası elde edilmedi.
